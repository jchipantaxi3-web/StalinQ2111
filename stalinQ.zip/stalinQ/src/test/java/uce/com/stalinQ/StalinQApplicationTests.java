package uce.com.stalinQ;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StalinQApplicationTests {

	@Test
	void contextLoads() {
	}

}
